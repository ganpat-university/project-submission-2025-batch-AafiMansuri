(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_alerts_page_tsx_780a2849._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_alerts_page_tsx_780a2849._.js",
  "chunks": [
    "static/chunks/node_modules_1a53c8a7._.js",
    "static/chunks/components_0c5b5a14._.js"
  ],
  "source": "dynamic"
});
