(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_page_tsx_780a2849._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_page_tsx_780a2849._.js",
  "chunks": [
    "static/chunks/_8d86a0c2._.js"
  ],
  "source": "dynamic"
});
