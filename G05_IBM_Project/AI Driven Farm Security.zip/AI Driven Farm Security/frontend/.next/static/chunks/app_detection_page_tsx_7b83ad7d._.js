(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_detection_page_tsx_7b83ad7d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_detection_page_tsx_7b83ad7d._.js",
  "chunks": [
    "static/chunks/_82030807._.js"
  ],
  "source": "dynamic"
});
