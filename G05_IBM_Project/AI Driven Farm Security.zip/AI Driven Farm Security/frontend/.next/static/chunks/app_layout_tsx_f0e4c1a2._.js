(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__23ac364f._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_805ce520._.js",
    "static/chunks/node_modules_27c45bd1._.js",
    "static/chunks/_0da3942e._.js"
  ],
  "source": "dynamic"
});
