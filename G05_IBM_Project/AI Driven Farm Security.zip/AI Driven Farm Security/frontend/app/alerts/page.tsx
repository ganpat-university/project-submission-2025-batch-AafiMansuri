import AlertsHeader from '@/components/alerts/AlertsHeader'
import AlertsTable from '@/components/alerts/AlertsTable'

const AlertsNotifications = () => {
  return (
    <div className="flex flex-col gap-6 p-6 h-full">
    <AlertsHeader />
    <div className="flex-1">
      <AlertsTable />
    </div>
  </div>
  )
}

export default AlertsNotifications