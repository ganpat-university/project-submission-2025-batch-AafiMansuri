'use client'

import React, { useEffect, useState } from 'react'
import AlarmControl from '@/components/control-panel/AlarmControl'
import GateControl from '@/components/control-panel/GateControl'
import RfidLogs from '@/components/control-panel/RfidLogs'

type LogEntry = {
  action: 'Entry' | 'Exit' | string
  card_id: string
  timestamp: string
  user: string
}

const ControlPanel = () => {
  const [logs, setLogs] = useState<LogEntry[] | null>(null)

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await fetch('http://ibm.nuviontech.com/controlpannel')
        const data = await res.json()
        setLogs(data.logs)
      } catch (err) {
        console.error('Failed to fetch RFID logs:', err)
      }
    }

    fetchLogs()
  }, [])

  // Show full-page loading spinner
  if (!logs) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-gray-400 border-t-black"></div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 p-6 h-full">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Control Panel</h1>
        <p className="text-muted-foreground">
          Manage your farm security mechanisms and view access logs
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <GateControl />
        <AlarmControl />
      </div>
      <div className="flex-1">
        <RfidLogs logs={logs} />
      </div>
    </div>
  )
}

export default ControlPanel
