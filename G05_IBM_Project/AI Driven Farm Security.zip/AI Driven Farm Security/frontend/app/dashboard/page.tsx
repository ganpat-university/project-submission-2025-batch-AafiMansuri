'use client'

import React, { useEffect, useState } from 'react'
import SensorGrid from '@/components/dashboard/SesnorGrid'
import AlertsSection from '@/components/dashboard/AlertSection'
import AlertTrends from '@/components/dashboard/AlertTrends'
import DashboardHeader from '@/components/dashboard/DashboardHeader'

type DashboardData = {
  temperature?: {
    value: number
    unit: string
    sensor: string
  }
  smoke_level?: {
    value: number
    unit: string
    sensor: string
  }
  flame_detection?: {
    value: string
    sensor: string
  }
  human_touch?: {
    value: string
    sensor: string
  }
  recent_alerts: {
    type: string
    time: string
    status: 'Resolved' | 'Critical' | 'Pending' | string
  }[]
}

const Dashboard = () => {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null)

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const response = await fetch('http://ibm.nuviontech.com/dashboard')
        const data = await response.json()
        setDashboardData(data)
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error)
      }
    }

    fetchDashboardData()
  }, [])

  if (!dashboardData) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-gray-400 border-t-black"></div>
      </div>
    )
  }  

  return (
    <div className="flex flex-col gap-6 p-6 h-full">
      <DashboardHeader />
      <SensorGrid data={dashboardData} />
      <div className="grid gap-6 md:grid-cols-2 flex-1">
        <AlertsSection alerts={dashboardData.recent_alerts} />
        <AlertTrends alerts={dashboardData.recent_alerts} />
      </div>
    </div>
  )
}

export default Dashboard
