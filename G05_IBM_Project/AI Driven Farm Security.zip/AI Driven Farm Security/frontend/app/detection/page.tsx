import { ImageUploader } from "@/components/detection/image-uploader"
import { ModelSelector } from "@/components/detection/model-selector"
import { DetectionResults } from "@/components/detection/detection-results"

export default function DetectionPage() {
  return (
    <div className="flex flex-col gap-6 p-6 h-full">
        <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Image Detection</h1>
            <p className="text-muted-foreground">Upload images to detect fire hazards or animals on your farm</p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <ImageUploader />
        <ModelSelector />
      </div>
      <div className="flex-1">
        <DetectionResults />
      </div>
    </div>
  )
}
