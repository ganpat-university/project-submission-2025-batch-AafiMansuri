"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { 
  LayoutDashboard, 
  Settings2, 
  Bell, 
  Home,
  ChevronLeft,
  ChevronRight,
  ScanEye 
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { ThemeToggle } from "@/components/ThemeToggle"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  onCollapse?: (collapsed: boolean) => void
}

export function Sidebar({ className, onCollapse }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const pathname = usePathname()

  const routes = [
    {
      label: "Dashboard",
      icon: LayoutDashboard,
      href: "/dashboard",
    },
    {
      label: "Control Panel",
      icon: Settings2,
      href: "/control-panel",
    },
    {
      label: "Alerts & Notifications",
      icon: Bell,
      href: "/alerts",
    },
    {
      label: "Detection",
      icon: ScanEye,
      href: "/detection",
    },
  ]

  const handleCollapse = () => {
    const newCollapsed = !isCollapsed
    setIsCollapsed(newCollapsed)
    onCollapse?.(newCollapsed)
  }

  return (
    <div className={cn("flex flex-col h-full", className)}>
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <div className={cn(
            "flex items-center gap-2 mb-2",
            isCollapsed && "justify-center"
          )}>
            <Home className="h-4 w-4" />
            <h2 className={cn(
              "text-lg font-semibold tracking-tight",
              isCollapsed && "hidden"
            )}>
              Farm Security
            </h2>
          </div>
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-start gap-2",
              isCollapsed && "justify-center"
            )}
            onClick={handleCollapse}
          >
            {isCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <>
                <ChevronLeft className="h-4 w-4" />
                <span>Collapse sidebar</span>
              </>
            )}
          </Button>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="space-y-1">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors",
                  pathname === route.href ? "bg-accent" : "transparent",
                  isCollapsed && "justify-center"
                )}
              >
                <route.icon className="h-4 w-4" />
                {!isCollapsed && <span>{route.label}</span>}
              </Link>
            ))}
          </div>
        </ScrollArea>
      </div>
      
      <div className="mt-auto p-3">
        <ThemeToggle isCollapsed={isCollapsed} />
      </div>
    </div>
  )
} 