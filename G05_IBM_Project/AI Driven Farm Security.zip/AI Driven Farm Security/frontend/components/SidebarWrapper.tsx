"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Sidebar } from "./Sidebar"

export function SidebarWrapper() {
  const [isCollapsed, setIsCollapsed] = useState(false)

  return (
    <div className={cn(
      "border-r bg-background transition-all duration-300",
      isCollapsed ? "w-16" : "w-64"
    )}>
      <Sidebar onCollapse={setIsCollapsed} />
    </div>
  )
} 