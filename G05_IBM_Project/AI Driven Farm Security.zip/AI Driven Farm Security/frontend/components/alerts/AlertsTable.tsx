"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreHorizontal, AlertCircle, CheckCircle2, Clock } from "lucide-react"

type Alert = {
  id: number
  timestamp: string
  sensor: string
  location: string
  severity: string
  status: string
}

type IncomingAlert = {
  location: string
  sensor: string
  severity: string
  status: string
  timestamp: string
}

const AlertsTable = () => {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const res = await fetch("http://ibm.nuviontech.com/notification")
        const data = await res.json()
        const formatted = (data.alerts as IncomingAlert[]).map((a, index) => ({
          id: index + 1,
          ...a
        }))
        setAlerts(formatted)
      } catch (err) {
        console.error("Failed to fetch alerts:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchAlerts()
  }, [])

  const markAsResolved = (id: number) => {
    setAlerts(alerts.map((alert) => (alert.id === id ? { ...alert, status: "Resolved" } : alert)))
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-muted dark:border-white border-t-transparent"></div>
      </div>
    )
  }

  return (
    <Card className="border-none shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">Security Alerts</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              {/* <TableHead className="w-[40px]"><Checkbox /></TableHead> */}
              <TableHead className="font-medium">Timestamp</TableHead>
              <TableHead className="font-medium">Sensor</TableHead>
              <TableHead className="font-medium">Location</TableHead>
              <TableHead className="font-medium">Severity</TableHead>
              <TableHead className="font-medium">Status</TableHead>
              <TableHead className="w-[80px] font-medium">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {alerts.map((alert) => (
              <TableRow key={alert.id} className="group cursor-pointer hover:bg-muted/50 transition-colors">
                {/* <TableCell><Checkbox className="group-hover:border-primary" /></TableCell> */}
                <TableCell>
                  <div className="flex flex-col">
                    <span className="font-medium">{alert.timestamp.split(" ")[0]}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {alert.timestamp.split(" ")[1]}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="font-medium">{alert.sensor}</TableCell>
                <TableCell className="text-muted-foreground">{alert.location}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      alert.severity === "High"
                        ? "destructive"
                        : alert.severity === "Medium"
                        ? "default"
                        : "outline"
                    }
                    className="font-medium"
                  >
                    {alert.severity}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      alert.status === "Resolved"
                        ? "outline"
                        : alert.status === "Critical"
                        ? "destructive"
                        : "default"
                    }
                    className="font-medium flex items-center gap-1"
                  >
                    {alert.status === "Resolved" ? (
                      <CheckCircle2 className="h-3 w-3" />
                    ) : (
                      <AlertCircle className="h-3 w-3" />
                    )}
                    {alert.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-[160px]">
                      <DropdownMenuItem onClick={() => markAsResolved(alert.id)}>
                        <CheckCircle2 className="mr-2 h-4 w-4" />
                        Mark as resolved
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <AlertCircle className="mr-2 h-4 w-4" />
                        View details
                      </DropdownMenuItem>
                      {/* <DropdownMenuItem>
                        <Clock className="mr-2 h-4 w-4" />
                        Assign to user
                      </DropdownMenuItem> */}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

export default AlertsTable
