"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BellRing, BellOff } from "lucide-react"

const AlarmControl = () => {
  const [isActive, setIsActive] = useState(false)
  const toggleAlarm = () => {
    //  API call to toggle the alarm
    setIsActive(!isActive)
  }
  return (
    <Card>
      <CardHeader>
        <CardTitle>Alarm System</CardTitle>
        <CardDescription>Emergency buzzer control</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center gap-4 py-6">
        <div className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-destructive">
          {isActive ? (
            <BellRing className="h-12 w-12 text-destructive animate-pulse" />
          ) : (
            <BellOff className="h-12 w-12 text-muted-foreground" />
          )}
        </div>
        <Badge variant={isActive ? "destructive" : "outline"} className="text-sm">
          {isActive ? "Alarm Active" : "Alarm Inactive"}
        </Badge>
      </CardContent>
      <CardFooter>
        <Button onClick={toggleAlarm} variant={isActive ? "destructive" : "default"} className="w-full">
          {isActive ? "Deactivate Alarm" : "Activate Alarm"}
        </Button>
      </CardFooter>
    </Card>
  )
}

export default AlarmControl