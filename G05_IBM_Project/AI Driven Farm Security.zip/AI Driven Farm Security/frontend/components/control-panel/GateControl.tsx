"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Lock, Unlock } from "lucide-react"


const GateControl = () => {
    const [isOpen, setIsOpen] = useState(false)
    const toggleGate = () => {
        //  API call to toggle the gate
        setIsOpen(!isOpen)
    }
    return (
<Card>
      <CardHeader>
        <CardTitle>Farm Gate Control</CardTitle>
        <CardDescription>ESP8266-controlled gate mechanism</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center gap-4 py-6">
        <div className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-primary">
          {isOpen ? <Unlock className="h-12 w-12 text-primary" /> : <Lock className="h-12 w-12 text-primary" />}
        </div>
        <Badge variant={isOpen ? "default" : "secondary"} className="text-sm">
          {isOpen ? "Gate Open" : "Gate Closed"}
        </Badge>
      </CardContent>
      <CardFooter>
        <Button onClick={toggleGate} className="w-full">
          {isOpen ? "Close Gate" : "Open Gate"}
        </Button>   
      </CardFooter>
    </Card>
  )
}

export default GateControl