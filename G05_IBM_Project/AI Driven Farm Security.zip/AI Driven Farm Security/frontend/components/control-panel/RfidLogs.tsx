'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'

type LogEntry = {
  action: 'Entry' | 'Exit' | string
  card_id: string
  timestamp: string
  user: string
}

type RfidLogsProps = {
  logs: LogEntry[]
}

const RfidLogs = ({ logs }: RfidLogsProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>RFID Access Logs</CardTitle>
        <CardDescription>Recent farm access records</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Timestamp</TableHead>
              <TableHead>Card ID</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs.map((log, idx) => (
              <TableRow key={idx}>
                <TableCell>
                  <div className="flex flex-col">
                    <span className="font-medium">{log.timestamp.split(' ')[0]}</span>
                    <span className="text-xs text-muted-foreground">{log.timestamp.split(' ')[1]}</span>
                  </div>
                </TableCell>
                <TableCell className="font-mono">{log.card_id}</TableCell>
                <TableCell>{log.user}</TableCell>
                <TableCell>
                  <Badge variant={log.action === 'Entry' ? 'default' : 'secondary'}>{log.action}</Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

export default RfidLogs
