import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, Filter } from "lucide-react"

type Alert = {
  type: string
  time: string // e.g., "2025-04-15 14:35"
  status: "Resolved" | "Critical" | "Pending" | string
}

type AlertSectionProps = {
  alerts: Alert[]
}

const AlertSection = ({ alerts }: AlertSectionProps) => {
  return (
    <Card className="col-span-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Recent Alerts</CardTitle>
          <CardDescription>Latest security events</CardDescription>
        </div>
        <Button variant="outline" size="sm">
          <Filter className="mr-2 h-4 w-4" />
          Filter
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.map((alert: Alert, index: number) => {
            const [date, time] = alert.time.split(" ")
            return (
              <div
                key={index}
                className="flex items-center justify-between rounded-lg border p-3"
              >
                <div className="space-y-1">
                  <p className="text-sm font-medium leading-none">
                    {alert.type}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-medium">{date}</span>
                    <span className="text-muted-foreground/60">|</span>
                    <span>{time}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant={
                      alert.status === "Resolved"
                        ? "outline"
                        : alert.status === "Critical"
                        ? "destructive"
                        : "default"
                    }
                  >
                    {alert.status}
                  </Badge>
                  {alert.status !== "Resolved" && (
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <CheckCircle className="h-4 w-4" />
                      <span className="sr-only">Mark as reviewed</span>
                    </Button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

export default AlertSection
