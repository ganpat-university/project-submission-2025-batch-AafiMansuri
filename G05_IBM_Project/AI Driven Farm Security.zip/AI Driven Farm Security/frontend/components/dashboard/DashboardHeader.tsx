import { Clock } from "lucide-react"

const DashboardHeader = () => {
  return (
    <div className="flex flex-col gap-2">
      <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
      <div className="flex items-center text-muted-foreground">
        <Clock className="mr-2 h-4 w-4" />
        <span>Last updated: {new Date().toLocaleString()}</span>
      </div>
    </div>
  )
}

export default DashboardHeader