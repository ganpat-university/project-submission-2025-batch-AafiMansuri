import {
  Flame,
  Thermometer,
  Wind,
  CheckCircle,
  User,
  AlertCircle,
} from "lucide-react"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

type SensorGridProps = {
  data: {
    temperature?: { value: number }
    smoke_level?: { value: number }
    flame_detection?: { value: string }
    human_touch?: { value: string }
  }
}

const SensorGrid = ({ data }: SensorGridProps) => {
  const sensorData = [
    {
      id: 1,
      name: "Temperature",
      value: data.temperature?.value !== undefined ? `${data.temperature.value}°C` : "N/A",
      status: data.temperature?.value && data.temperature.value > 40 ? "Alert" : "Normal",
      icon: Thermometer,
    },
    {
      id: 2,
      name: "Smoke Level",
      value: data.smoke_level?.value !== undefined ? `${data.smoke_level.value}` : "N/A",
      status: data.smoke_level?.value && data.smoke_level.value > 500 ? "Alert" : "Normal",
      icon: Wind,
    },
    {
      id: 3,
      name: "Flame Detection",
      value: data.flame_detection?.value ?? "N/A",
      status: data.flame_detection?.value === "Flame Detected" ? "Alert" : "Normal",
      icon: Flame,
    },
    {
      id: 4,
      name: "Human Touch",
      value: data.human_touch?.value ?? "N/A",
      status: data.human_touch?.value === "Detected" ? "Alert" : "Normal",
      icon: User,
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {sensorData.map((sensor) => (
        <Card key={sensor.id} className="overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">{sensor.name}</CardTitle>
            <sensor.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sensor.value}</div>
            <Badge
              variant={sensor.status === "Normal" ? "outline" : "destructive"}
              className={`mt-2 inline-flex items-center gap-1 ${
                sensor.status === "Normal"
                  ? "bg-green-50 text-green-700 hover:bg-green-50 hover:text-green-700"
                  : "bg-red-50 text-red-700 dark:text-white hover:bg-red-50 hover:text-red-700"
              }`}
            >
              {sensor.status === "Normal" ? (
                <CheckCircle className="h-3 w-3" />
              ) : (
                <AlertCircle className="h-3 w-3" />
              )}
              {sensor.status}
            </Badge>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

export default SensorGrid
