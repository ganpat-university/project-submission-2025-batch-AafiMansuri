"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"

export function DetectionResults() {
  const [isLoading, setIsLoading] = useState(false)
  const [results, setResults] = useState<{
    model: string
    detections: Array<{
      label: string
      confidence: number
      box: { x: number; y: number; width: number; height: number }
    }>
    annotatedImage: string
  } | null>(null)

  useEffect(() => {
    const handleStartDetection = (e: Event) => {
      const { model } = (e as CustomEvent).detail
      setIsLoading(true)
      setResults(null)
    }

    const handleDetectionComplete = (e: Event) => {
      const { model } = (e as CustomEvent).detail
      setIsLoading(false)

      // Generate mock results based on the model
      if (model === "Fire") {
        setResults({
          model: "Fire",
          detections: [
            {
              label: "Fire",
              confidence: 0.92,
              box: { x: 120, y: 80, width: 150, height: 120 },
            },
            {
              label: "Smoke",
              confidence: 0.87,
              box: { x: 200, y: 50, width: 100, height: 80 },
            },
          ],
          annotatedImage: "/placeholder.svg?height=400&width=600",
        })
      } else if (model === "Animal") {
        setResults({
          model: "Animal",
          detections: [
            {
              label: "Deer",
              confidence: 0.89,
              box: { x: 150, y: 100, width: 200, height: 180 },
            },
            {
              label: "Fox",
              confidence: 0.76,
              box: { x: 350, y: 220, width: 120, height: 90 },
            },
          ],
          annotatedImage: "/placeholder.svg?height=400&width=600",
        })
      }
    }

    window.addEventListener("startDetection", handleStartDetection)
    window.addEventListener("detectionComplete", handleDetectionComplete)

    return () => {
      window.removeEventListener("startDetection", handleStartDetection)
      window.removeEventListener("detectionComplete", handleDetectionComplete)
    }
  }, [])

  if (!isLoading && !results) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Detection Results</CardTitle>
          <CardDescription>Upload an image and run detection to see results</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center p-12 text-muted-foreground">
          No detection results yet. Please upload an image and run detection.
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Detection Results</CardTitle>
        <CardDescription>
          {isLoading
            ? "Processing your image..."
            : results
              ? `${results.model} detection results`
              : "Upload an image and run detection to see results"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-[400px] w-full rounded-lg" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-[250px]" />
              <Skeleton className="h-4 w-[200px]" />
            </div>
          </div>
        ) : results ? (
          <div className="space-y-6">
            <div className="relative border rounded-lg overflow-hidden">
              <img
                src={results.annotatedImage || "/placeholder.svg"}
                alt="Annotated result"
                className="w-full h-auto object-contain"
              />

              {/* Simulated annotation boxes */}
              {results.detections.map((detection, index) => (
                <div
                  key={index}
                  className="absolute border-2 border-primary"
                  style={{
                    left: `${detection.box.x}px`,
                    top: `${detection.box.y}px`,
                    width: `${detection.box.width}px`,
                    height: `${detection.box.height}px`,
                  }}
                >
                  <Badge className="absolute -top-6 left-0 text-xs">
                    {detection.label} ({Math.round(detection.confidence * 100)}%)
                  </Badge>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Detected Objects:</h3>
              <ul className="space-y-1">
                {results.detections.map((detection, index) => (
                  <li key={index} className="flex items-center justify-between border-b pb-1">
                    <span>{detection.label}</span>
                    <Badge variant="outline">{Math.round(detection.confidence * 100)}% confidence</Badge>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}
