"use client"

import { useState } from "react"
import { Flame, Rabbit } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"

export function ModelSelector() {
  const [selectedModel, setSelectedModel] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const handleModelSelect = (model: string) => {
    setSelectedModel(model)
  }

  const handleDetect = () => {
    if (!selectedModel) {
        toast.error("No model selected", {
            description: "Please select a detection model first",
          })
      return
    }

    // Simulate processing
    setIsProcessing(true)

    // Dispatch a custom event that the results component will listen for
    const event = new CustomEvent("startDetection", {
      detail: { model: selectedModel },
    })
    window.dispatchEvent(event)

    setTimeout(() => {
      setIsProcessing(false)

      // Dispatch event when processing is complete
      const completeEvent = new CustomEvent("detectionComplete", {
        detail: { model: selectedModel },
      })
      window.dispatchEvent(completeEvent)

      toast.success("Detection Complete", {
        description: `${selectedModel} detection completed successfully`,
      })
    }, 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Select Detection Model</CardTitle>
        <CardDescription>Choose the type of detection to perform</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <Button
            variant={selectedModel === "Fire" ? "default" : "outline"}
            className="h-24 flex flex-col gap-2"
            onClick={() => handleModelSelect("Fire")}
          >
            <Flame className={`h-8 w-8 ${selectedModel === "Fire" ? "text-primary-foreground" : "text-primary"}`} />
            <span>Detect Fire</span>
          </Button>
          <Button
            variant={selectedModel === "Animal" ? "default" : "outline"}
            className="h-24 flex flex-col gap-2"
            onClick={() => handleModelSelect("Animal")}
          >
            <Rabbit className={`h-8 w-8 ${selectedModel === "Animal" ? "text-primary-foreground" : "text-primary"}`} />
            <span>Detect Animal</span>
          </Button>
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={handleDetect} disabled={!selectedModel || isProcessing}>
          {isProcessing ? "Processing..." : "Run Detection"}
        </Button>
      </CardFooter>
    </Card>
  )
}
